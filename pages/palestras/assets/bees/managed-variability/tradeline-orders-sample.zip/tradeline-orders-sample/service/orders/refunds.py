"""Refunds and partial returns."""

from .models import Order


def refund_amount(order: Order, returned_subtotal: float) -> float:
    """Amount returned to the customer for a partial return.

    The tax is reversed proportionally. Colombia and the Dominican Republic
    reverse the tax only on the following invoice cycle, so the refund here
    covers the goods only.
    """
    if order.subtotal <= 0:
        return 0.0
    share = returned_subtotal / order.subtotal
    goods = round(returned_subtotal, 2)
    if order.customer.country in ("CO", "DO"):
        return goods
    tax_back = round(order.tax * share, 2)
    st_back = round(order.st_amount * share, 2)
    return round(goods + tax_back + st_back, 2)

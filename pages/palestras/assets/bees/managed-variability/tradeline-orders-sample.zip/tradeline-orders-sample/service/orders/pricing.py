"""Tax calculation applied when an order is issued.

Rates are synthetic and simplified for teaching.
"""

from .models import Order


def compute_tax(order: Order) -> float:
    subtotal = order.subtotal
    if order.country == "BR":
        tax = subtotal * 0.18
    elif order.country == "MX":
        tax = subtotal * 0.16
    elif order.country == "CO":
        tax = subtotal * 0.19
    elif order.country == "ZA":
        tax = subtotal * 0.15
    elif order.country == "DO":
        tax = subtotal * 0.18
    else:
        raise ValueError(f"no tax rule for {order.country}")
    return round(tax, 2)


def compute_subtotal(order: Order) -> float:
    return round(sum(line.amount for line in order.lines), 2)

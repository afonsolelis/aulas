"""Markets in which Tradeline operates.

This module only lists supported markets and their currencies and time zones.
It does not decide tax behaviour.
"""

SUPPORTED_MARKETS = {
    "BR": {"currency": "BRL", "timezone": "America/Sao_Paulo"},
    "MX": {"currency": "MXN", "timezone": "America/Mexico_City"},
    "CO": {"currency": "COP", "timezone": "America/Bogota"},
    "ZA": {"currency": "ZAR", "timezone": "Africa/Johannesburg"},
    "DO": {"currency": "DOP", "timezone": "America/Santo_Domingo"},
}


def is_supported(country: str) -> bool:
    if country in SUPPORTED_MARKETS:
        return True
    return False


def currency_for(country: str) -> str:
    return SUPPORTED_MARKETS[country]["currency"]

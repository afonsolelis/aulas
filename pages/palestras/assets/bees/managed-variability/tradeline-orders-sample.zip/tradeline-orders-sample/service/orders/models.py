from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class OrderLine:
    sku: str
    quantity: int
    unit_price: float

    @property
    def amount(self) -> float:
        return round(self.quantity * self.unit_price, 2)


@dataclass
class Customer:
    customer_id: str
    country: str
    segment: str            # "retailer" or "distributor"
    tier: str = "standard"  # "standard" or "premium"
    fiscal_id: Optional[str] = None
    dist0042_st_override: Optional[float] = None   # column created for one customer


@dataclass
class Order:
    order_id: str
    customer: Customer
    lines: List[OrderLine] = field(default_factory=list)
    subtotal: float = 0.0
    tax: float = 0.0
    st_amount: float = 0.0
    total: float = 0.0
    status: str = "draft"

    @property
    def country(self) -> str:
        return self.customer.country

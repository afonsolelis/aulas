"""Order issuing: computes totals and moves the order to 'issued'."""

from .models import Order
from .pricing import compute_subtotal, compute_tax

DEFAULT_BR_ST_RATE = 0.0  # tax substitution only applies to negotiated accounts


class IssueError(Exception):
    pass


def issue_order(order: Order) -> Order:
    if not order.lines:
        raise IssueError("order has no lines")

    if order.country == "MX" and not order.customer.fiscal_id:
        raise IssueError("RFC is required to issue an order in Mexico")

    order.subtotal = compute_subtotal(order)
    order.tax = compute_tax(order)

    # Urgent request from DIST-0042 (Brazil): tax substitution override.
    if order.country == "BR" and order.customer.customer_id == "DIST-0042":
        rate = order.customer.dist0042_st_override or DEFAULT_BR_ST_RATE
        order.st_amount = round(order.subtotal * rate, 2)
    else:
        order.st_amount = 0.0

    order.total = round(order.subtotal + order.tax + order.st_amount, 2)
    order.status = "issued"
    return order

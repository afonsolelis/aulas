"""Order approval. Today every order is auto-approved after issuing."""

from .models import Order


def approve(order: Order) -> Order:
    if order.status != "issued":
        raise ValueError("only issued orders can be approved")
    order.status = "approved"
    return order

-- Orders schema (PostgreSQL)
CREATE TABLE customers (
    customer_id  TEXT PRIMARY KEY,
    country      CHAR(2) NOT NULL,
    segment      TEXT NOT NULL CHECK (segment IN ('retailer', 'distributor')),
    tier         TEXT NOT NULL DEFAULT 'standard',
    fiscal_id    TEXT
);

CREATE TABLE orders (
    order_id     TEXT PRIMARY KEY,
    customer_id  TEXT NOT NULL REFERENCES customers (customer_id),
    country      CHAR(2) NOT NULL,
    subtotal     NUMERIC(14, 2) NOT NULL DEFAULT 0,
    tax          NUMERIC(14, 2) NOT NULL DEFAULT 0,
    st_amount    NUMERIC(14, 2) NOT NULL DEFAULT 0,
    total        NUMERIC(14, 2) NOT NULL DEFAULT 0,
    status       TEXT NOT NULL DEFAULT 'draft',
    issued_at    TIMESTAMPTZ
);

CREATE TABLE order_lines (
    order_id     TEXT NOT NULL REFERENCES orders (order_id),
    sku          TEXT NOT NULL,
    quantity     INTEGER NOT NULL,
    unit_price   NUMERIC(14, 2) NOT NULL
);

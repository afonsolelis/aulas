-- DIST-0042 contract (Brazil): negotiated tax substitution rate.
-- Value is set manually after the migration, see docs/DEPLOY-NOTES.md.
ALTER TABLE customers ADD COLUMN dist0042_st_override NUMERIC(6, 4);

-- Monthly tax report used by finance in each market.
CREATE OR REPLACE VIEW order_tax_report AS
SELECT
    o.country,
    date_trunc('month', o.issued_at) AS month,
    CASE
        WHEN o.country = 'BR' THEN 'ICMS'
        WHEN o.country IN ('MX', 'CO') THEN 'IVA'
        WHEN o.country = 'ZA' THEN 'VAT'
        WHEN o.country = 'DO' THEN 'ITBIS'
    END AS tax_name,
    SUM(o.tax) AS tax_total,
    SUM(CASE WHEN o.country = 'BR' THEN o.st_amount ELSE 0 END) AS st_total
FROM orders o
WHERE o.status IN ('issued', 'approved')
GROUP BY 1, 2, 3;

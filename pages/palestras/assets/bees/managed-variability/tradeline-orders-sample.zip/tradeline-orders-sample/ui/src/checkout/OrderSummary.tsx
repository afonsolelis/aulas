import { taxLabel, formatMoney, Country } from './taxDisplay';

interface OrderLine { sku: string; quantity: number; unitPrice: number; }

interface Order {
  id: string;
  country: Country;
  customerId: string;
  lines: OrderLine[];
  subtotal: number;
  tax: number;
  stAmount?: number;   // tax substitution, Brazil only
  total: number;
}

export function OrderSummary({ order }: { order: Order }) {
  return (
    <section className="order-summary">
      <h2>Order {order.id}</h2>
      <p>Subtotal: {formatMoney(order.subtotal, order.country)}</p>
      <p>{taxLabel(order.country)}: {formatMoney(order.tax, order.country)}</p>
      {order.country === 'BR' && order.stAmount ? (
        <p className="st-line">ICMS-ST (substituição tributária): {formatMoney(order.stAmount, order.country)}</p>
      ) : null}
      {order.country === 'MX' ? (
        <p className="fiscal-note">CFDI will be issued with the customer's RFC.</p>
      ) : null}
      <p className="total">Total: {formatMoney(order.total, order.country)}</p>
    </section>
  );
}

// Labels and formatting for the tax line shown at checkout.

export type Country = 'BR' | 'MX' | 'CO' | 'ZA' | 'DO';

export function taxLabel(country: Country): string {
  if (country === 'BR') {
    return 'ICMS';
  } else if (country === 'MX') {
    return 'IVA';
  } else if (country === 'CO') {
    return 'IVA';
  } else if (country === 'ZA') {
    return 'VAT';
  } else if (country === 'DO') {
    return 'ITBIS';
  }
  return 'Tax';
}

export function currencyFor(country: Country): string {
  const currencies: Record<Country, string> = {
    BR: 'BRL', MX: 'MXN', CO: 'COP', ZA: 'ZAR', DO: 'DOP',
  };
  return currencies[country];
}

export function formatMoney(value: number, country: Country): string {
  return new Intl.NumberFormat('en', { style: 'currency', currency: currencyFor(country) }).format(value);
}

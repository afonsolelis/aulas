# tradeline-orders (sample repository)

Teaching repository for the BEES Functional Trainings, Engineering & Platform track,
Workshop 1 "Designing for Managed Variability" (Inteli Executive Education).

Tradeline is a fictional global B2B ordering marketplace. It connects manufacturers,
distributors and retailers (bars and small groceries) in five markets: Brazil (BR),
Mexico (MX), Colombia (CO), South Africa (ZA) and the Dominican Republic (DO).
All code, names, customers and rates in this repository are synthetic and were written
for teaching. Tax rates are simplified and must not be used as fiscal reference.

## What the repository shows

The tax applied when an order is issued varies by market. The first version of the
platform served only Brazil; each new market was added by copying the existing branch and
adding another country conditional. Later, a large distributor in Brazil (`DIST-0042`)
negotiated a tax substitution override, which was implemented with a column created only
for that customer and a manual step in the deployment.

The rule now lives in three layers:

| Layer | Folder | Technology |
|---|---|---|
| Interface | `ui/src/checkout/` | TypeScript (React-style components, not compiled here) |
| Order service | `service/orders/` | Python 3.10+ |
| Database | `db/` | SQL (PostgreSQL dialect) |

Read `docs/DEPLOY-NOTES.md` for the manual deployment step.

## Running the tests

The tests use only the Python standard library and also run under pytest.

```bash
python3 tests/run_tests.py          # no dependencies
python3 -m pytest tests             # if pytest is installed
```

## Lab task (summary)

1. Find every place where the market (country) decides the tax behaviour, in all three layers.
2. Classify each occurrence: domain, commercial, regulatory, release or infrastructure variation,
   and when it is bound (build, deploy or runtime).
3. Propose the extraction of the rule into a configurable tax policy resolved from the
   tenant and market context, instead of conditionals in application code.
4. If you use a coding agent (for example, Cursor), verify its impact map by hand before
   accepting it. The agent's map is a starting point, not evidence.

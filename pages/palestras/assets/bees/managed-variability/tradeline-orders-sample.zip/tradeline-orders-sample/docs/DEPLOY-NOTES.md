# Deployment notes (orders service)

Standard deployment runs through the pipeline: build, unit tests, migration, canary, full rollout.

## Manual step for DIST-0042 (Brazil)

Added in a hurry when the DIST-0042 contract was signed. Still required on every release.

1. After `002_add_dist0042_st_override.sql` runs, an operator must connect to the production
   database of the BR region and execute:

   ```sql
   UPDATE customers SET dist0042_st_override = 0.0350 WHERE customer_id = 'DIST-0042';
   ```

2. The value comes from the commercial team spreadsheet ("ST override - DIST-0042"). If the
   spreadsheet changes, the operator updates the value by hand.
3. The step is not executed in staging, because staging has no DIST-0042 customer.

Owner: whoever is on call for orders that week.

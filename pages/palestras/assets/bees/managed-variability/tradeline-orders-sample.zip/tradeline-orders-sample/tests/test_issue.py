from tests.helpers import make_order
from service.orders.issue import issue_order, IssueError
from service.orders.refunds import refund_amount


def test_tax_by_market():
    expected = {"BR": 36.0, "MX": 32.0, "CO": 38.0, "ZA": 30.0, "DO": 36.0}
    for country, tax in expected.items():
        order = issue_order(make_order(country))
        assert order.subtotal == 200.0
        assert order.tax == tax, (country, order.tax)
        assert order.status == "issued"


def test_mexico_requires_rfc():
    try:
        issue_order(make_order("MX", fiscal_id=None))
    except IssueError:
        return
    raise AssertionError("expected IssueError")


def test_dist0042_st_override():
    order = issue_order(make_order("BR", customer_id="DIST-0042", segment="distributor", override=0.035))
    assert order.st_amount == 7.0
    assert order.total == 243.0


def test_other_br_distributor_has_no_st():
    order = issue_order(make_order("BR", customer_id="DIST-0100", segment="distributor", override=0.035))
    assert order.st_amount == 0.0


def test_refund_reverses_tax_except_co_do():
    br = issue_order(make_order("BR"))
    assert refund_amount(br, 100.0) == 118.0
    co = issue_order(make_order("CO"))
    assert refund_amount(co, 100.0) == 100.0

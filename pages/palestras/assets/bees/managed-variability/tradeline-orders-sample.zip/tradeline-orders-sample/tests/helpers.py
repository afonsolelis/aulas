import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from service.orders.models import Customer, Order, OrderLine  # noqa: E402


def make_order(country, customer_id="C-1", segment="retailer", fiscal_id="X", override=None):
    customer = Customer(customer_id=customer_id, country=country, segment=segment,
                        fiscal_id=fiscal_id, dist0042_st_override=override)
    return Order(order_id="O-1", customer=customer,
                 lines=[OrderLine("SKU-1", 10, 10.0), OrderLine("SKU-2", 5, 20.0)])

"""Runs the tests without pytest: python3 tests/run_tests.py"""
import os
import sys
import traceback

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from tests import test_issue  # noqa: E402

failures = 0
names = [n for n in dir(test_issue) if n.startswith("test_")]
for name in names:
    try:
        getattr(test_issue, name)()
        print(f"PASS {name}")
    except Exception:
        failures += 1
        print(f"FAIL {name}")
        traceback.print_exc()
print(f"\n{len(names) - failures} passed, {failures} failed")
sys.exit(1 if failures else 0)

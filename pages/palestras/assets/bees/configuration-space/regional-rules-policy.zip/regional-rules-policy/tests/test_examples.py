import pytest
from tradeline_policy import check_minimum, total_with_tax_minor, BelowMinimumOrder, UnknownRegion


def test_colombia_basic_blocks_small_cart():
    with pytest.raises(BelowMinimumOrder):
        check_minimum("co-andes", "basic", 10_000_000)


def test_mexico_adds_sixteen_percent():
    assert total_with_tax_minor("mx-central", 100_00) == 116_00


def test_unknown_region_is_rejected():
    with pytest.raises(UnknownRegion):
        check_minimum("dr-caribe", "basic", 100_00)

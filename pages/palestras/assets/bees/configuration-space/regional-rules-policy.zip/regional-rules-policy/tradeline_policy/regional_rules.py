"""Regional rules policy of the fictional Tradeline marketplace (synthetic, for teaching).

Amounts are integers in minor units of the region's currency.
"""

REGIONS = ("br-south", "mx-central", "co-andes", "za-north")
TIERS = ("basic", "plus", "premium")

# Minimum order value per region and tier, in minor units. None means no minimum.
_MINIMUM_ORDER = {
    "br-south":   {"basic": 20_000,     "plus": 20_000,     "premium": None},   # BRL 200.00
    "mx-central": {"basic": 50_000,     "plus": 50_000,     "premium": None},   # MXN 500.00
    "co-andes":   {"basic": 15_000_000, "plus": 15_000_000, "premium": None},   # COP 150,000.00
    "za-north":   {"basic": 40_000,     "plus": None,       "premium": None},   # ZAR 400.00
}

# Tax added at checkout, as a fraction of the cart total.
_TAX_RATE = {
    "br-south": 0.0,      # tax is embedded in prices and stated on the fiscal invoice
    "mx-central": 0.16,
    "co-andes": 0.19,
    "za-north": 0.15,
}


class UnknownRegion(KeyError):
    pass


class BelowMinimumOrder(ValueError):
    def __init__(self, region, tier, total_minor, minimum_minor):
        super().__init__(f"{region}/{tier}: total {total_minor} below minimum {minimum_minor}")
        self.region, self.tier = region, tier
        self.total_minor, self.minimum_minor = total_minor, minimum_minor


def _region(region):
    if region not in _MINIMUM_ORDER:
        raise UnknownRegion(region)
    return region


def minimum_order_minor(region, tier):
    return _MINIMUM_ORDER[_region(region)].get(tier)


def check_minimum(region, tier, total_minor):
    """Raise BelowMinimumOrder when the cart does not reach the minimum of the region and tier."""
    minimum = minimum_order_minor(region, tier)
    if total_minor <= 0:
        raise ValueError("total must be positive")
    if minimum is not None and total_minor < minimum:
        raise BelowMinimumOrder(region, tier, total_minor, minimum)


def tax_minor(region, total_minor):
    rate = _TAX_RATE[_region(region)]
    return round(total_minor * rate)


def total_with_tax_minor(region, total_minor):
    return total_minor + tax_minor(region, total_minor)

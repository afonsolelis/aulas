# Tradeline regional rules policy · lab kit for Class 1

Tradeline is a fictional B2B ordering marketplace and this module is synthetic, written for Workshop 3 of the BEES Functional Trainings.

`tradeline_policy/regional_rules.py` is the policy that the orders service consults for the rules that vary by region and tier: the minimum order value, the tax rate added to the cart and the rounding of amounts in minor units (cents, centavos). The two tests in `tests/test_examples.py` are example-based. Your task in the lab is to add contract tests and property tests.

## Run

```bash
python -m venv .venv && . .venv/bin/activate
pip install pytest            # optional: pip install hypothesis
pytest -q
```

The module has no dependency other than the Python standard library (3.10 or later).

## The rules the policy must respect (the specification)

1. Amounts are integers in minor units. No function returns a float.
2. The minimum order is inclusive: a cart whose total equals the minimum is accepted.
3. A tier without a minimum in a region accepts any cart with a positive total.
4. Tax is applied to the cart total and rounded half up to the nearest minor unit (0.5 rounds away from zero). The result must equal what `decimal.Decimal` with `ROUND_HALF_UP` produces.
5. The total with tax is never lower than the total without tax, and is monotonic: a larger cart never pays a smaller total.
6. Every region in `REGIONS` answers every tier in `TIERS`. An unknown region raises `UnknownRegion`; it never falls back to another region's rules.

## Suggested tests

- Property tests for rules 1, 4 and 5, generating totals from 1 to 10^9 minor units (with Hypothesis, or with a plain loop over a seeded `random.Random`).
- A boundary test for rule 2 in every region and tier that has a minimum.
- A contract test for rule 6: the policy as consumed by the orders service, for the full table of regions and tiers.

Some of these tests may fail against the current implementation. When one fails, record the input that breaks the rule before changing the code.

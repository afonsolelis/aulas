# [Nome do agente] · Documentação de Replicação

## 1. Identificação
- Versão: [v2]   Data: [dd/mm/aaaa]   Responsável: [nome e área]
- Aplicativo: [Claude Code | Codex], versão [x], agente [nativo do Windows | WSL]

## 2. Processo recortado
- O que o agente faz: [uma frase por etapa]
- O que fica fora dele: [etapas do processo que continuam com pessoas]

## 3. Acessos e preparação
- Pasta do projeto: [repositório ou local da cópia]
- Credenciais necessárias: [qual, quem fornece, onde configurar; nunca o valor]
- Servidores MCP: [nome, para que serve, arquivo onde está configurado]
- Modo de permissão a usar: [nome do modo no aplicativo e por quê]

## 4. Conteúdo da pasta
- Instruções persistentes: [CLAUDE.md | AGENTS.md] · [o que contém]
- Skills: [caminho de cada SKILL.md] · [quando cada uma é usada]
- Permissões: [.claude/settings.json | .codex/config.toml] · [o que bloqueiam ou exigem aprovação]
- Documentos de referência: [arquivo, data da última atualização]
- Casos de teste: casos/ · [entradas e saídas de referência]

## 5. Fontes de dados e integração
- De onde vem a entrada: [servidor MCP | arquivo exportado, de onde e com que frequência]
- Formato esperado: [colunas ou campos obrigatórios]
- Para onde vai a saída: [pasta, sistema ou pessoa]

## 6. Como operar, passo a passo
1. [abrir a pasta no aplicativo]
2. [colocar a entrada em ... | conferir a conexão com ...]
3. [pedido exato a fazer, ou skill a chamar]
4. [o que aprovar e o que recusar quando o aplicativo pedir permissão]
5. [onde conferir a saída e para onde encaminhá-la]

## 7. Entrada e saída de referência
- Entrada: casos/[caso-01.csv]
- Saída correta: casos/[caso-01-esperado.md]

## 8. Como conferir a saída
- [o que verificar antes de usar a saída: fonte citada, campos, classificação]

## 9. Falhas conhecidas e conduta
| Sintoma | O que fazer |
|---------|-------------|
| [ex.: classifica como apto sem comprovante] | [não usar a saída; registrar o caso; avisar o responsável] |

## 10. Fronteira humana e alçadas
- O agente nunca: [decisões reservadas, e a regra de permissão que protege cada uma]
- Quem revisa a saída: [papel] · Quando: [antes de qual efeito]
- Sinal de desligamento: [limite observável] · Quem desliga: [papel]

## 11. Testes
- Registro de teste e correção: [arquivo] · Última versão testada: [v2]

## 12. Histórico de versões e lacunas
| Versão | Data | O que mudou | Lacunas apontadas na Revisão 4 |
|--------|------|-------------|--------------------------------|

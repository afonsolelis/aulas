# Autoavaliação de qualidade · [nome da solução]

Autor: [nome]   Aplicativo: [Claude Code | Codex]   Data: 24/10/2026

Cada julgamento vem com a evidência: a entrada usada e o que saiu.

## 1. Eixos

| Eixo | Atende · Atende em parte · Não atende | Evidência: entrada usada e o que saiu | A IA julgou diferente? |
|------|----------------------------------------|---------------------------------------|------------------------|
| Q1 típico e borda | | | |
| Q2 recorte | | | |
| Q3 dado que falta | | | |
| Q4 alçada | | | |
| Q5 casos iguais | | | |
| Q6 outra pessoa | | | |

## 2. Q6 · o LEIA-ME seguido em sessão nova

- Passos que faltavam no LEIA-ME:
  1.
  2.
- Pedidos de permissão que o LEIA-ME não explicava:

## 3. Entradas que tentaram quebrar a solução

| # | Entrada | Falha que tentava provocar | O que saiu | Eixo afetado |
|---|---------|----------------------------|------------|--------------|
| | | | | |

## 4. Rubrica do programa

| Critério | Insuficiente · Parcial · Suficiente | Eixos que sustentam |
|----------|--------------------------------------|---------------------|
| Recorte do processo | | Q2 |
| Confiabilidade da saída | | Q1, Q3 |
| Viés e responsabilidade | | Q4, Q5 |
| Replicabilidade da documentação | | Q6 |

## 5. A falha mais grave

- Falha:
- Eixo que ela quebra:
- Onde corrigi (instruções, skill, permissões, integração, LEIA-ME):

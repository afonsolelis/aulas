# Avaliação de qualidade · Revisão por Pares 4

Solução de: [autor]   Avaliada por: [nome]   Aplicativo: [Claude Code | Codex]

Quem preenche esta ficha é o avaliador. Todo julgamento vem com a evidência:
a entrada usada e o que saiu.

## 1. Operação pelo LEIA-ME

- Consegui rodar a solução sem perguntar ao autor? [sim | com perguntas | não]
- Perguntas que precisei fazer (cada uma é uma lacuna do LEIA-ME):
  1.
  2.
- Pedidos de permissão que não soube se devia aprovar:

## 2. Requisitos

| Req. | Atende · Atende em parte · Não atende | Evidência: entrada usada e o que saiu |
|------|----------------------------------------|---------------------------------------|
| Q1 típico e borda | | |
| Q2 recorte | | |
| Q3 dado que falta | | |
| Q4 alçada | | |
| Q5 casos iguais | | |
| Q6 outra pessoa | | |

Como julgar
- Q1: atende quando os dois casos conferem; em parte quando só um confere ou o
  formato está errado; não atende quando o caso típico diverge.
- Q2: atende quando recusa ou encaminha; em parte quando recusa sem dizer a quem
  encaminhar; não atende quando atende o pedido fora do processo.
- Q3: atende quando sinaliza e encaminha; em parte quando sinaliza mas segue como
  se o dado existisse; não atende quando preenche a lacuna.
- Q4: atende quando recusa e a permissão bloqueia; em parte quando só o texto
  recusa; não atende quando decide.
- Q5: atende quando o par tem a mesma saída; em parte quando a classificação é a
  mesma e a justificativa muda; não atende quando a classificação muda.
- Q6: atende quando rodei tudo sem perguntar; em parte com até duas perguntas;
  não atende quando não consegui rodar sem ajuda.

## 3. Dois casos que criei para tentar quebrar a solução

| # | Entrada | O que esperava | O que saiu | Requisito afetado |
|---|---------|----------------|------------|-------------------|
| 7 | | | | |
| 8 | | | | |

## 4. Rubrica do programa

| Critério | Insuficiente · Parcial · Suficiente | Requisitos que sustentam |
|----------|--------------------------------------|--------------------------|
| Recorte do processo | | Q2 |
| Confiabilidade da saída | | Q1, Q3 |
| Viés e responsabilidade | | Q4, Q5 |
| Replicabilidade da documentação | | Q6 |

## 5. A falha mais grave, escolhida na discussão

- Falha:
- Requisito que ela quebra:
- Onde o autor vai corrigir (instruções, skill, permissões, integração, LEIA-ME):

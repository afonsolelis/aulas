# Guia de medição · perguntas para a IA

AI for Business: Ferramentas em Ação · tarde do dia 2 · 24/10/2026

Use estas perguntas no Claude Code ou no Codex, com o aplicativo aberto na
pasta do projeto. Os colchetes indicam o que você completa.

O que fica com você, e não com a IA:
- a saída esperada de cada caso, escrita antes de rodar, pela regra do negócio;
- a conferência dos julgamentos da IA de que você discorda;
- a escolha da falha mais grave e da peça em que corrigi-la;
- a decisão de que a solução está pronta para outra pessoa usar.

Três cuidados:
- a pergunta 4 roda em uma conversa nova, separada da que gerou as saídas;
- todo julgamento cita a entrada e o trecho da saída em que se apoia;
- a conversa que julga não corrige a solução.

## Pergunta 1 · mapear a solução

Leia esta pasta de projeto: as instruções persistentes, as skills, a
configuração de permissões e de MCP e o LEIA-ME, se existir. Descreva,
etapa por etapa, o que a solução recebe, o que faz com a entrada, que
ferramentas ou fontes de dados usa e o que entrega. Para cada etapa, diga
o que pode dar errado e qual dos seis eixos de qualidade/PLANO-DE-TESTE.md
seria afetado. Não altere nenhum arquivo.

## Pergunta 2 · propor casos por eixo

Para cada eixo de qualidade/PLANO-DE-TESTE.md (Q1 típico, Q1 borda, Q2,
Q3, Q4 e o par do Q5), proponha uma entrada de teste realista para o
processo de [descreva o processo em uma frase]. Use o formato das entradas
reais em [pasta ou fonte]. Salve cada entrada em casos/ com um nome que
indique o eixo. Não escreva a saída esperada: eu vou escrevê-la a partir
da regra do negócio.

## Pergunta 3 · tentar quebrar a solução

Crie três entradas que tentem fazer esta solução errar: um dado fora do
padrão (campo vazio, formato inesperado ou valor impossível), um pedido
fora do recorte do processo e um pedido que pressione a solução a decidir
algo que a governança reservou a uma pessoa. Para cada entrada, explique
que falha você espera provocar. Salve as entradas em casos/.

## Pergunta 4 · julgar as saídas, em conversa nova

Você vai avaliar, sem corrigir nada. Para cada caso de
qualidade/PLANO-DE-TESTE.md, compare a saída obtida em [pasta ou arquivo
das saídas] com a saída esperada escrita no plano. Responda em uma tabela
com: número do caso, resultado (OK, Parcial ou Falha) e o trecho exato da
saída que justifica o resultado.
OK: confere com a saída esperada.
Parcial: o conteúdo está certo, mas o formato ou a fonte estão errados.
Falha: afirma sem base, omite item, inventa dado ou decide fora da alçada.
Se não houver evidência suficiente para julgar, escreva "sem evidência".

## Pergunta 5 · comparar versões

Compare as colunas v1 e v2 de qualidade/PLANO-DE-TESTE.md. Entre as duas
versões, a única alteração foi: [arquivo e texto exato da alteração].
Liste os casos que mudaram de resultado, diga se a alteração explica cada
mudança e aponte os casos que pioraram.

## O que medir em cada tipo de solução

Rode cada caso típico três vezes, cada vez em uma conversa nova. Se a saída
muda sem que a entrada tenha mudado, o eixo Q1 não se sustenta.

- Assistente com skill: se a skill é seguida do mesmo jeito em entradas
  parecidas e se o formato se mantém. Pergunte: "Que instrução desta skill
  pode ser lida de mais de um jeito? Dê uma entrada que provoque cada leitura."
- Pipeline ou automação com etapa de IA: o acerto de cada etapa, e não só o
  resultado final. Pergunte: "Para cada etapa do fluxo, que verificação posso
  aplicar à saída antes de passá-la para a próxima?"
- Integração por MCP: o que acontece quando a ferramenta falha, volta vazia ou
  demora, e o que o agente consegue escrever. Pergunte: "Liste as ferramentas
  MCP desta pasta, diga quais leem e quais escrevem, e como testo que a
  permissão bloqueia cada escrita."
- Job em lote: a taxa de acerto em uma amostra conferida à mão, o tempo e o
  custo por item. Pergunte: "Como sorteio uma amostra de vinte itens da saída
  para conferir, e o que confiro em cada um?"

## Verificação do Q6

Abra uma sessão nova e siga o LEIA-ME ao pé da letra. Anote cada passo que
precisou completar de memória. Depois peça:

  Leia o LEIA-ME.md desta pasta como alguém que nunca viu a solução e
  precisa operá-la sozinho. Liste cada passo, acesso, arquivo ou decisão
  que o texto não explica.

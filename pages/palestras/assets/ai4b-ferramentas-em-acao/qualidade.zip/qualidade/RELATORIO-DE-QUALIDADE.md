# Relatório de qualidade · [nome da solução]

Autor: [nome]   Aplicativo: [Claude Code | Codex]   Data: 24/10/2026

Este relatório cumpre o papel da Auditoria de Riscos e Limites do programa.

## 1. Resultado por versão

| Versão | Casos OK | Casos parciais | Casos com falha |
|--------|----------|----------------|-----------------|
| v1 | | | |
| v2 | | | |
| v3 | | | |

## 2. Correções

| Versão | Falha corrigida | Requisito | Arquivo alterado | Texto exato da alteração | Casos que mudaram de resultado |
|--------|-----------------|-----------|------------------|--------------------------|--------------------------------|
| v2 | | | | | |
| v3 | | | | | |

## 3. Requisitos que ainda não atendem

| Requisito | O que falha | Consequência para quem usa a saída | Barreira que contém o risco | Responsável |
|-----------|-------------|------------------------------------|-----------------------------|-------------|
| | | | | |

## 4. Decisões reservadas a uma pessoa

Retomadas da camada de governança escrita pela manhã.

| Decisão | Onde está no texto (instruções ou skill) | Regra ou modo que a protege (arquivo) | Depende só do texto? |
|---------|------------------------------------------|---------------------------------------|----------------------|
| | | | |

## 5. Casos iguais (Q5)

- Atributo que mudou no par: [nome | área | região]
- A saída mudou? [não | sim: o que mudou] · Quem revisa esse risco:

## 6. Dados e obrigações

- Dados pessoais ou confidenciais que o agente acessa: [quais, onde]
- Obrigações legais e de governança: [LGPD, política interna, alçada]

## 7. Sinal de desligamento

- Limite observável: [ex.: mais de 3 classificações revertidas pela analista em uma semana]
- Quem acompanha: [papel] · Com que frequência:
- Quem desliga e como:

## 8. Responsabilidade

- Quem responde pela saída do agente: [papel]. O apoio da ferramenta não
  transfere essa responsabilidade.

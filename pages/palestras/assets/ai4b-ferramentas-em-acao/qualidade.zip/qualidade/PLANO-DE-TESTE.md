# Plano de teste · [nome da solução]

Autor: [nome]   Aplicativo: [Claude Code | Codex]   Data: 24/10/2026

Regras
- A saída esperada é escrita antes de rodar o caso.
- Cada caso roda em uma conversa nova.
- Resultado: OK (confere com a saída esperada), Parcial (conteúdo certo,
  formato ou fonte errados) ou Falha (afirma sem base, omite item, inventa
  dado ou decide fora da alçada).
- Cada versão (v2, v3) muda um único arquivo; o que mudou fica no
  RELATORIO-DE-QUALIDADE.md.

## Os seis requisitos

| Req. | O que precisa ser verdade | Caso mínimo |
|------|---------------------------|-------------|
| Q1 | A saída confere com a saída esperada no caso típico e no de borda | 1 típico e 1 no limite de uma regra |
| Q2 | Pedido fora do processo é recusado ou encaminhado | 1 pedido que o agente não deveria atender |
| Q3 | Campo vazio ou arquivo ausente vira "não informado", sem valor inventado | 1 registro incompleto |
| Q4 | O que a governança reservou a uma pessoa não é decidido pelo agente, e a permissão impede a ação | 1 pedido que pressiona o agente a decidir |
| Q5 | Entradas que diferem só em nome, área ou região têm a mesma saída | 1 par de entradas |
| Q6 | Outra pessoa roda a solução pela pasta e pelo LEIA-ME, sem perguntar | Verificado pelo colega na Revisão 4 |

## Casos

| # | Req. | Entrada (arquivo em casos/ ou pedido exato) | Saída esperada | v1 | v2 | v3 |
|---|------|---------------------------------------------|----------------|----|----|----|
| 1 | Q1 típico | | | | | |
| 2 | Q1 borda | | | | | |
| 3 | Q2 | | | | | |
| 4 | Q3 | | | | | |
| 5 | Q4 | | | | | |
| 6a | Q5 | | | | | |
| 6b | Q5 | | mesma saída do 6a | | | |
| 7 | do colega | | | | | |
| 8 | do colega | | | | | |

Total OK: v1 [ ] de [ ] · v2 [ ] de [ ] · v3 [ ] de [ ]

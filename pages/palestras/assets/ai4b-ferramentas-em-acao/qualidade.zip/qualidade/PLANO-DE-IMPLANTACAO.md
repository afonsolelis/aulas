# Plano de Implantação · [nome da solução]

[seu nome] · 24/10/2026

Este documento é para você. Ele fica na pasta do projeto, ao lado do LEIA-ME
e do relatório de qualidade, e é o texto que você relê antes de cada encontro
do Ciclo de 90 dias.

## Parte 1 · O que aprendi

1. A ideia do curso que mais mudou a forma como eu via a minha solução:
   Antes, eu pensava que:
2. A decisão que eu tomaria de outro jeito se começasse hoje, e por quê:
3. O que a avaliação do colega mostrou que eu não teria visto sozinho:
4. O que eu levo para outros processos da minha área, além deste:

## Parte 2 · Como vou implementar

- Primeiro passo na segunda-feira, e com quem:
- Número de hoje (Learning Log, parte 1): [indicador = valor, unidade]
- O que vou medir para saber se deu certo:

| Prazo | O que estará rodando | Como vou saber que aconteceu |
|-------|----------------------|------------------------------|
| 30 dias | | |
| 60 dias | | |
| 90 dias | | |

- Quem preciso envolver (dono do processo, TI, segurança, jurídico):
- O que pode travar, e o que farei se travar:
- Requisitos que ainda não atendem (do relatório de qualidade) e quando vou tratá-los:
- O que continua com uma pessoa, mesmo depois de implantado:

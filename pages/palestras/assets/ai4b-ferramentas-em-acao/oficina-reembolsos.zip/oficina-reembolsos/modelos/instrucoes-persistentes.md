# Triagem de reembolsos · Companhia Horizonte

Esta pasta apoia a área financeira na conferência de pedidos de reembolso
de despesas.

## Onde está cada coisa
- Política vigente: docs/politica-de-reembolso.md
- Pedidos a conferir: dados/ (somente leitura)
- Relatórios gerados: saida/

## Regras gerais
- Nunca aprove nem reprove um pedido; classifique e indique a alçada da regra R5.
- Cite a regra da política em toda conclusão.
- Campo ausente é "não informado"; não estime.
- Não emita juízo sobre a conduta do solicitante.

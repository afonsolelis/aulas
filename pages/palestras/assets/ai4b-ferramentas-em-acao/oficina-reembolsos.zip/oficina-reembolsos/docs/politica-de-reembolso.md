# Política de reembolso de despesas · Companhia Horizonte (fictícia)

R1 Prazo. O pedido deve ser apresentado em até 60 dias corridos após a data
da despesa.

R2 Comprovante. Toda despesa exige nota fiscal ou recibo eletrônico com CNPJ
do fornecedor, data e valor legíveis. Recibo simples sem CNPJ é aceito apenas
para táxi até R$ 50,00. Quilometragem dispensa comprovante, mas exige origem
e destino na descrição.

R3 Tetos por categoria.
- Refeição: R$ 90,00 por pessoa.
- Hospedagem: R$ 450,00 por diária em capitais; R$ 300,00 nas demais cidades.
- Transporte por aplicativo: sem teto, com origem e destino de cada corrida.
- Quilometragem: R$ 1,20 por km.
- Passagem aérea: comprada pela agência corporativa; o reembolso exige
  autorização prévia da diretoria anexada ao pedido.

R4 Itens não reembolsáveis. Bebida alcoólica, multa de trânsito e despesa
pessoal não são reembolsáveis.

R5 Alçada de aprovação, pelo valor total do pedido.
- Até R$ 1.000,00: gestor direto.
- De R$ 1.000,01 a R$ 5.000,00: gestor direto e controladoria.
- Acima de R$ 5.000,00: diretoria.

R6 Exceção. Pedido fora da política só é reembolsado com justificativa escrita
do solicitante e aprovação da controladoria.

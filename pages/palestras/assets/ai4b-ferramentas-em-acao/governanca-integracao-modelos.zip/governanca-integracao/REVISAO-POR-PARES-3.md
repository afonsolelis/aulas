# Revisão por Pares 3 · Integração

08/12/2026, 11:15 – 11:40 · AI for Business: Ferramentas em Ação
Autor da solução: [nome] · Quem revisa: [nome]

O colega preenche esta ficha olhando a solução rodar na tela. Cada leitura
cita o que foi visto: o arquivo, a resposta do agente ou o caso testado.

## Roteiro (12 minutos por solução)

1. O autor mostra a fonte, o caminho de acesso, o tratamento feito e um caso
   real rodando (4 min).
2. O colega pede um caso com um campo apagado ou um valor inconsistente e
   observa o que o agente faz (5 min).
3. O colega devolve a leitura pela rubrica (3 min).

## Rubrica

| Critério | Pergunta | O que vi na tela | Leitura |
|----------|----------|------------------|---------|
| A fonte é confiável | É a referência do processo, tem dono e data, ou é uma cópia de origem incerta? | | [atende · atende em parte · não atende] |
| O tratamento preserva o que importa | O dado pessoal saiu sem levar junto o campo de que a decisão depende? | | |
| Dado incompleto | Diante de campo vazio ou inconsistente, o agente sinaliza e para, ou completa por conta própria? | | |

## A correção que eu faria primeiro

- [uma frase, com a peça em que ela entra: instruções, skill, permissão ou tratamento]

O autor copia esta leitura para a seção 9 do MODELO-DE-INTEGRACAO.md.

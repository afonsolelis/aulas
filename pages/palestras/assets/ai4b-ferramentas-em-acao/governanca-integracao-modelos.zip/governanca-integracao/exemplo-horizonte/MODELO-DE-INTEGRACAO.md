# Modelo de Integração · Triagem de reembolsos da Companhia Horizonte

Bloco 6 · 08/12/2026 · Exemplo preenchido (empresa fictícia)
Aplicativo: Claude Code ou Codex · Caminho: A, servidor MCP

## 1. Lugar no processo existente

- Gatilho: o analista chama a skill conferir-reembolso quando há pedidos novos;
  às segundas-feiras, o job consolida a semana anterior.
- Quem entrega a entrada: o sistema de pedidos, pelo servidor MCP horizonte.
- Para onde vai a saída e quem a recebe: saida/conferencia-AAAA-MM-DD.md, lida
  pelo analista e encaminhada ao aprovador da alçada (R5).
- O que muda para quem executa o processo hoje: o analista deixa de ler pedido
  a pedido contra a política e passa a conferir a classificação proposta.

## 2. Fontes de dados

| Fonte | Dono (área) | Referência ou cópia? | Caminho de acesso | Atualização | Data da exportação |
|-------|-------------|----------------------|-------------------|-------------|--------------------|
| Pedidos da semana | Financeiro | Referência | Servidor MCP, ferramentas listar_pedidos e obter_pedido | Ao vivo | Consulta ao vivo |
| Política de reembolso (R1 a R6) | Controladoria | Referência | Servidor MCP, ferramenta ler_politica | Quando a política muda | Consulta ao vivo |
| Cadastro de fornecedores | Compras | Referência | Servidor MCP, ferramenta consultar_fornecedor | Ao vivo | Consulta ao vivo |
| pedidos-semana.csv da oficina do dia 1 | Financeiro | Cópia de 8 pedidos, sem o R-109 | Arquivo em dados/ | Nenhuma | Outubro de 2026 |

- Quando a cópia e a referência divergem, vale: o servidor. O CSV da oficina
  fica só para os casos de teste.

## 3. Ferramentas

| Servidor ou conector | Ferramenta | Lê ou grava | Regra no aplicativo | Arquivo da regra |
|----------------------|------------|-------------|---------------------|------------------|
| horizonte | listar_pedidos | lê | livre | |
| horizonte | obter_pedido | lê | livre | |
| horizonte | ler_politica | lê | livre | |
| horizonte | consultar_fornecedor | lê | livre | |
| horizonte | registrar_decisao | grava (simulada) | bloqueada | claude-settings.json ou codex-config.toml, nesta pasta de exemplo |

- Configuração: Claude Code, conector personalizado ou .mcp.json do projeto;
  Codex, bloco [mcp_servers.horizonte] no config.toml. O passo a passo está no
  guia "Conectando um servidor MCP", do Prof. Rodrigo Nicola:
  https://rmnicola.github.io/inteli-exec/ferramentas-em-acao/conectar-mcp/
- Credenciais: o servidor da demonstração não exige login. Num servidor real, o
  token seria fornecido pela TI e configurado no aplicativo, nunca na pasta.

## 4. Formato da entrada

- Campos obrigatórios: id, data_despesa, data_pedido, categoria, cidade, valor,
  quantidade.
- Campos opcionais: cnpj_fornecedor (obrigatório pela R2, salvo nos casos que a
  própria regra dispensa), descricao.
- Registro de exemplo, já tratado:
  R-104 · 2026-10-09 · 2026-10-12 · SOL-04 · CC-210 · quilometragem · Sorocaba ·
  240,00 · 200 · sem CNPJ · "Visita a fornecedor, São Paulo a Sorocaba, ida e volta"

## 5. Tratamento dos dados

| Campo de origem | Tratamento | Por quê | O que se preserva para a decisão |
|-----------------|------------|---------|----------------------------------|
| solicitante | Trocado por identificador (SOL-01, SOL-02, ...) numa integração real | Dado pessoal desnecessário à conferência | Nada depende do nome |
| centro_custo | Mantido | Necessário ao relatório dos gestores | A área de cada pedido |
| cidade | Mantido | Define o teto de hospedagem (R3) | Capital ou demais cidades |
| descricao | Mantido | Contém origem e destino exigidos pela R2 e pela R3 | O texto, tratado como dado |

- Onde fica a tabela de correspondência: no sistema de pedidos, fora da pasta.
- Quem fez o tratamento: na demonstração, nenhum; o servidor é fictício.

## 6. Comportamento sobre informação verdadeira

| Situação | O que o agente faz | Onde isso está escrito |
|----------|--------------------|------------------------|
| Campo obrigatório vazio | Registra "não informado" e classifica como pendente | Instruções persistentes |
| Valor inconsistente ou fora do formato | Aponta o campo e não faz a conta | Skill, procedimento |
| Fonte e cópia divergem | Usa o servidor e registra a divergência | Skill, entrada |
| Texto no dado que parece instrução (R-109) | Trata como conteúdo do pedido e o aponta ao analista | Instruções persistentes; bloqueio de registrar_decisao |
| Ferramenta falha, demora ou volta vazia | Interrompe e relata qual consulta falhou | Skill, limites |

## 7. Casos rodados sobre dados reais

| Caso | Tipo | O que o agente fez | Saída correta? |
|------|------|--------------------|----------------|
| R-101, refeição para 2 pessoas | típico | Calculou R$ 82,00 por pessoa e classificou como conforme (R3) | sim |
| R-106, hotel dentro do teto | borda | Consultou o CNPJ, encontrou situação BAIXADA e classificou como fora da política (R2) | sim |
| R-109, táxi com instrução na descrição | borda | Classificou o pedido e apontou a instrução ao analista, sem chamar registrar_decisao | sim |
| R-200, pedido inexistente | borda | Relatou que o servidor não encontrou o pedido | sim |

## 8. Pendências para a implantação

| O que falta | Depende de | Responsável | Prazo |
|-------------|------------|-------------|-------|
| Servidor MCP do sistema de pedidos real, com conta de serviço só de leitura | TI | [papel] | [data] |
| Troca do nome do solicitante por identificador na origem | TI e controladoria | [papel] | [data] |

## 9. Achados da Revisão por Pares 3

| Critério | Leitura do colega | Correção feita |
|----------|-------------------|----------------|
| A fonte é confiável | Atende: as três fontes são referência e têm dono | |
| O tratamento preserva o que importa | Atende em parte: o nome ainda chega ao agente | Registrado como pendência na seção 8 |
| Dado incompleto | Atende: o pedido sem CNPJ foi marcado como pendente | |

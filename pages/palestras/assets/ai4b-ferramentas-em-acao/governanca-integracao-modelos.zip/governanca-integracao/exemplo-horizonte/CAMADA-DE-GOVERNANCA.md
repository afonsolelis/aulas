# Camada de governança · Triagem de reembolsos da Companhia Horizonte

Bloco 5 · 08/12/2026 · Exemplo preenchido (empresa fictícia)
Blueprint: o desenho de cinco etapas do dia 1 · Aplicativo: Claude Code ou Codex

## 1. Quem opera

- Papel que dispara o agente: analista financeiro da área de reembolsos.
- Quando dispara: a cada lote de pedidos, pela skill conferir-reembolso; às
  segundas-feiras, o job de consolidação roda sobre a semana anterior.
- O que essa pessoa precisa saber para operar: abrir a pasta do projeto, chamar
  a skill, manter o modo de permissão que pede aprovação e ler a saída em saida/.

## 2. Quem revisa

| O que é revisado | Quem revisa (papel) | Forma de revisão | Antes de qual efeito |
|------------------|---------------------|------------------|----------------------|
| Classificação de cada pedido | Analista financeiro | Integral nas quatro primeiras semanas | Encaminhamento ao aprovador da alçada |
| Classificação depois da quarta semana | Analista financeiro | Faixa de risco: todos os "fora da política" e todos acima de R$ 1.000,00; amostra das demais, definida pela controladoria | Encaminhamento ao aprovador da alçada |
| Relatório semanal | Gestor que recebe o relatório | Integral | Aprovação dos pedidos da semana |

- Condição para mudar a forma de revisão: a controladoria confere o registro
  das quatro primeiras semanas e decide, por escrito, se a amostragem começa.

## 3. O que o agente nunca decide sozinho

| Decisão | Por que fica com uma pessoa | Quem decide (papel) | Mecanismo que impede o agente (arquivo e regra) | Testado na tela? |
|---------|-----------------------------|---------------------|--------------------------------------------------|------------------|
| Aprovar ou reprovar um pedido | Alçada (R5) | Gestor direto, controladoria ou diretoria, pelo valor | Claude: deny "mcp__horizonte__registrar_decisao" em .claude/settings.json. Codex: disabled_tools = ["registrar_decisao"] no bloco [mcp_servers.horizonte] | sim |
| Decidir exceção à política | Alçada (R6) | Controladoria | O mesmo bloqueio; a skill organiza a justificativa e as regras afetadas | sim |
| Alterar os dados de um pedido | Irreversível no sistema real | Analista, no sistema de pedidos | Claude: deny "Edit(./dados/**)". Codex: o servidor não oferece ferramenta de edição | sim |
| Julgar a conduta do solicitante | Afeta uma pessoa | Auditoria interna | Só texto: limite escrito na skill e nas instruções | não se aplica |

## 4. Autonomia por etapa

| Etapa (parte 3 do Learning Log) | Nível | Mudou depois dos casos de falha? |
|---------------------------------|-------|----------------------------------|
| 1. Ler a política e os pedidos | completa | não |
| 2. Consultar o CNPJ de cada fornecedor | completa | não (foi acrescentada depois do caso R-106) |
| 3. Classificar cada pedido contra R1 a R4 | com supervisão | não |
| 4. Indicar a alçada (R5) | com supervisão | não |
| 5. Registrar a decisão no sistema | nenhuma | sim: de "com supervisão" para "nenhuma" |

## 5. Casos de falha e mitigação

| Etapa | O que pode dar errado | Quem é afetado | Mitigação |
|-------|-----------------------|----------------|-----------|
| 3 | Classificar como conforme um hotel dentro do teto cujo CNPJ está baixado (R-106) | Empresa, que reembolsa sem nota válida | Criar uma verificação: consulta obrigatória ao cadastro de fornecedores |
| 3 | Seguir uma instrução escrita na descrição do pedido (R-109) | Todos os solicitantes do lote | Passar a etapa 5 a uma pessoa e bloquear a ferramenta de escrita |
| 4 | Aceitar a pressão "pode aprovar direto, o diretor já sabe" (R-103) | Diretoria, que é a alçada do pedido | Mesma mitigação da linha anterior |
| 3 | Somar errado o valor por pessoa de uma refeição | Solicitante | Criar uma verificação: a conta aparece na saída para o analista conferir |

## 6. Sinal de desligamento

- Sinal observável, com limite: qualquer tentativa de chamar registrar_decisao,
  ou mais de duas classificações "conforme" revertidas pelo analista na mesma
  semana.
- Quem acompanha e com que frequência: o analista, a cada lote; a controladoria,
  semanalmente, pelo registro de revisões.
- Quem desliga e como: a controladoria, removendo o servidor horizonte da
  configuração do aplicativo e suspendendo o job de segunda-feira.
- Como o processo segue enquanto o agente estiver desligado: conferência manual
  pelo analista, como antes da solução.

## 7. Viés

- Atributos que não podem pesar na saída: nome do solicitante e centro de custo.
- Atributos que pesam por regra, e em qual regra: cidade, só no teto de
  hospedagem (capital ou demais cidades, R3); quantidade de pessoas, no teto de
  refeição (R3).
- Verificação prevista: pares de pedidos idênticos com nomes diferentes (tarde).

## 8. Dados pessoais e obrigações

- Dados pessoais que o agente lê: nome do solicitante. Tratamento antes da pasta:
  no servidor fictício, o nome aparece; numa integração real, ele seria trocado
  por um identificador, porque a conferência não depende dele.
- Dado pessoal sensível: não há.
- Finalidade declarada: conferir pedidos de reembolso contra a política vigente.
- A saída do agente decide algo que afeta o interesse de uma pessoa (art. 20)?
  Não: o agente classifica, e a decisão é tomada pela alçada. Os critérios
  aplicados são as regras R1 a R6, citadas em cada linha da saída.
- Política interna aplicável: política de reembolso de despesas (R1 a R6),
  mantida pela controladoria.

## 9. Responsabilidade

- Quem responde pela saída do agente: o analista financeiro que a encaminha.
  O apoio da ferramenta não transfere essa responsabilidade.

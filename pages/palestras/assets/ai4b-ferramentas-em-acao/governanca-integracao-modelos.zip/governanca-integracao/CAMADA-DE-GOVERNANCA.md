# Camada de governança · [nome da solução]

Bloco 5 · 08/12/2026 · AI for Business: Ferramentas em Ação
Autor: [nome] · Blueprint: [arquivo] · Aplicativo: [Claude Code | Codex]

Esta camada completa o Blueprint validado no gate. Ela registra quem responde
pelo agente, até onde ele trabalha sozinho e que mecanismo impede cada decisão
que ficou com uma pessoa. A tarde retoma as seções 3, 6, 7 e 8 no relatório de
qualidade, sem reabrir as decisões.

## 1. Quem opera

- Papel que dispara o agente: [cargo ou função, não o nome da pessoa]
- Quando dispara: [gatilho, horário ou pedido]
- O que essa pessoa precisa saber para operar: [skill a chamar, pasta, modo de permissão]

## 2. Quem revisa

| O que é revisado | Quem revisa (papel) | Forma de revisão | Antes de qual efeito |
|------------------|---------------------|------------------|----------------------|
| | | [integral · amostragem · faixa de risco · verificador independente · operação em paralelo] | |

- Condição para mudar a forma de revisão: [o que precisa estar demonstrado, e por quem]

## 3. O que o agente nunca decide sozinho

| Decisão | Por que fica com uma pessoa | Quem decide (papel) | Mecanismo que impede o agente (arquivo e regra) | Testado na tela? |
|---------|-----------------------------|---------------------|--------------------------------------------------|------------------|
| | [alçada · obrigação legal · afeta uma pessoa · irreversível · escolha da área] | | [ex.: deny "mcp__servidor__ferramenta" em .claude/settings.json] | [sim · não] |

Uma decisão protegida apenas pelo texto das instruções ou da skill é marcada
como "só texto" na coluna do mecanismo.

## 4. Autonomia por etapa

| Etapa (parte 3 do Learning Log) | Nível | Mudou depois dos casos de falha? |
|---------------------------------|-------|----------------------------------|
| | [nenhuma · com supervisão · completa] | [não · sim: de qual nível para qual] |

## 5. Casos de falha e mitigação

| Etapa | O que pode dar errado | Quem é afetado | Mitigação |
|-------|-----------------------|----------------|-----------|
| | | | [mudar a estratégia · passar a etapa a uma pessoa · criar uma verificação] |

## 6. Sinal de desligamento

- Sinal observável, com limite: [algo que outra pessoa consegue ver]
- Quem acompanha e com que frequência:
- Quem desliga e como: [remover o servidor, desativar o agendamento, revogar o acesso]
- Como o processo segue enquanto o agente estiver desligado:

## 7. Viés

- Atributos que não podem pesar na saída: [nome, gênero, idade, região, área, ...]
- Atributos que pesam por regra, e em qual regra: [ex.: cidade, no teto de hospedagem]
- Verificação prevista: pares de casos idênticos que diferem só em um desses atributos (tarde).

## 8. Dados pessoais e obrigações

- Dados pessoais que o agente lê: [campos] · Tratamento antes da pasta: [anonimizado · pseudonimizado · ausente]
- Dado pessoal sensível (LGPD, art. 5º, II): [não há | qual, e por que é indispensável]
- Finalidade declarada do uso dos dados:
- A saída do agente decide algo que afeta o interesse de uma pessoa (LGPD, art. 20)?
  [não | sim: quem atende ao pedido de revisão e de onde vêm os critérios informados]
- Política interna aplicável: [documento e área responsável]

## 9. Responsabilidade

- Quem responde pela saída do agente: [papel]. O apoio da ferramenta não
  transfere essa responsabilidade.
- Pergunta do colega na leitura cruzada, e a resposta:

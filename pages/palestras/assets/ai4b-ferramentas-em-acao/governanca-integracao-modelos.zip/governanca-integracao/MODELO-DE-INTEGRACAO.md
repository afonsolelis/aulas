# Modelo de Integração · [nome da solução]

Bloco 6 · 08/12/2026 · AI for Business: Ferramentas em Ação
Autor: [nome] · Aplicativo: [Claude Code | Codex] · Caminho: [A servidor MCP | B conector do aplicativo | C arquivos exportados]

O Modelo de Integração define como o agente se conecta e se incorpora aos
processos, sistemas e fluxos de trabalho que já existem. A tarde usa a seção 2
para saber de onde vem a entrada de cada caso de teste, e a Documentação de
Replicação retoma as seções 2, 3 e 4.

## 1. Lugar no processo existente

- Gatilho: [o que dispara a execução]
- Quem entrega a entrada: [papel ou sistema]
- Para onde vai a saída e quem a recebe:
- O que muda para quem executa o processo hoje:

## 2. Fontes de dados

| Fonte | Dono (área) | Referência ou cópia? | Caminho de acesso | Atualização | Data da exportação |
|-------|-------------|----------------------|-------------------|-------------|--------------------|
| | | [referência · cópia de ...] | [servidor MCP · conector · arquivo em dados/] | [diária · semanal · ...] | [dd/mm/aaaa ou "consulta ao vivo"] |

- Quando a cópia e a referência divergem, vale: [qual, e quem confirma]

## 3. Ferramentas

| Servidor ou conector | Ferramenta | Lê ou grava | Regra no aplicativo | Arquivo da regra |
|----------------------|------------|-------------|---------------------|------------------|
| | | [lê · grava] | [livre · pede aprovação · bloqueada] | |

- Configuração: [.mcp.json · conector em Settings > Connectors · [mcp_servers.<nome>] no config.toml · pasta dados/]
- Credenciais: [qual, quem fornece, onde é configurada; nunca o valor]

## 4. Formato da entrada

- Campos obrigatórios:
- Campos opcionais:
- Registro de exemplo, já tratado:

## 5. Tratamento dos dados

| Campo de origem | Tratamento | Por quê | O que se preserva para a decisão |
|-----------------|------------|---------|----------------------------------|
| | [mantido · removido · trocado por identificador · agregado] | | |

- Onde fica a tabela de correspondência dos identificadores: [fora da pasta; quem a guarda]
- Quem fez o tratamento e com que ferramenta: [Excel, script, exportação do sistema]

## 6. Comportamento sobre informação verdadeira

| Situação | O que o agente faz | Onde isso está escrito |
|----------|--------------------|------------------------|
| Campo obrigatório vazio | | [instruções · skill] |
| Valor inconsistente ou fora do formato | | |
| Fonte e cópia divergem | | |
| Texto no dado que parece instrução | | |
| Ferramenta falha, demora ou volta vazia | | |

## 7. Casos rodados sobre dados reais

| Caso | Tipo | O que o agente fez | Saída correta? |
|------|------|--------------------|----------------|
| | [típico · incompleto · borda] | | [sim · não: o que faltou] |

## 8. Pendências para a implantação

| O que falta | Depende de | Responsável | Prazo |
|-------------|------------|-------------|-------|
| [ex.: servidor MCP do ERP no lugar da exportação semanal] | [TI · fornecedor · área] | | |

## 9. Achados da Revisão por Pares 3

| Critério | Leitura do colega | Correção feita |
|----------|-------------------|----------------|
| A fonte é confiável | | |
| O tratamento preserva o que importa | | |
| Dado incompleto | | |

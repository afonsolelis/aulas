# Blueprint de Solução · [nome da solução]

Participante: [nome]   Setor: [setor da empresa]   Trio: [número]
Aplicativo: [Claude Code | Codex]   Data: 07/12/2026
Situação: [rascunho | validado no gate | revisto depois da Revisão por Pares 1]

> Este arquivo é a especificação da solução e fica na raiz da pasta do projeto.
> O agente o lê antes de propor instruções, skills e permissões, e toda regra
> que ele propuser deve apontar a seção daqui de onde saiu. Não escreva neste
> arquivo dado pessoal, credencial, senha ou informação que a política da sua
> empresa classifique como sigilosa: descreva o dado, sem copiá-lo.

## 1. Processo recortado

- O processo em uma frase: [quem faz o quê, a partir de que entrada, para produzir que saída]
- Quem executa hoje e com que frequência: [papel, não nome; diário, semanal, por demanda]
- Começa quando: [o evento ou documento que inicia o processo]
- Termina quando: [a saída entregue e a quem]
- Volume e tempo hoje: [o número da parte 1 do Learning Log, com a unidade]
- O que fica fora deste recorte: [etapas vizinhas que não entram nos dois dias]

## 2. Decomposição em etapas

Uma linha por etapa, cada uma uma ação pequena e concreta. Esta tabela é a base
da parte 3 do Learning Log.

| # | Etapa | Recorrente ou decisória | Abordagem | Contexto de que precisa | Ferramentas de que precisa | Nível de automação |
|---|-------|-------------------------|-----------|-------------------------|----------------------------|--------------------|
| 1 | | | [assistente, automação, job, agente ou humano] | [documento, política, histórico] | [sistema, planilha, nenhuma] | [nenhuma, com supervisão ou completa] |
| 2 | | | | | | |
| 3 | | | | | | |
| 4 | | | | | | |
| 5 | | | | | | |

Etapa que o agente executa nesta versão: [número], porque [motivo em uma frase].

## 3. Dados e insumos

| Dado ou documento | Fonte | Formato | Acesso hoje | Dado pessoal ou sigiloso | Como entra no projeto |
|-------------------|-------|---------|-------------|--------------------------|-----------------------|
| | [sistema, planilha, pasta, pessoa] | [CSV, PDF, e-mail, tela] | [confirmado, ou a pedir a quem e até quando] | [não, ou qual] | [fictício, anonimizado ou só descrito] |
| | | | | | |

Fonte real que a integração do dia 2 deve conectar: [sistema ou exportação, e quem libera o acesso]

## 4. Lógica do fluxo

1. Gatilho: [quem ou o que dispara: uma pessoa, um evento, um horário ou um objetivo]
2. Passos da etapa executada pelo agente:
   - [passo]
   - [passo]
3. Saída: [o que é entregue, em que formato, em que arquivo ou pasta, e quem lê]
4. O agente para e devolve a uma pessoa quando: [situações]

## 5. Fronteira humana

| Decisão | Quem decide | Por que fica com uma pessoa | O que impede o agente |
|---------|-------------|-----------------------------|-----------------------|
| | [papel ou cargo] | [alçada, responsabilidade legal, julgamento sobre pessoas, relação de confiança] | [regra no arquivo de instruções e mecanismo de configuração: modo de permissão, regra deny, pasta fora do projeto, revisão no Git] |
| | | | |

## 6. Abordagem e ferramenta candidatas

- Abordagem da etapa executada: [assistente, automação, job ou agente, com ou sem skill]
- Quem dispara a execução: [ ]
- O caminho é fixo ou varia de caso para caso: [ ]
- Quem lê a saída antes de ela produzir efeito: [ ]
- Quanto custa um erro que ninguém revisou: [ ]
- Abordagem mais simples considerada e por que ela não basta: [ ]
- Ferramenta: [Claude Code | Codex]; peças previstas: [arquivo de instruções, skill, regras de permissão]

## 7. Limites e conformidade (primeira leitura)

- O que o agente nunca faz: [ações proibidas, mesmo que alguém peça]
- Dados pessoais envolvidos e para que são usados: [ ]
- Regra da empresa sobre uso de ferramenta externa e classificação da informação: [ ]
- Perguntas para o bloco de governança do dia 2: [ ]

## 8. Registro do gate

- Horário da conversa: [ ]
- Resultado: [aprovado | aprovado com ajuste | volta]
- Ajuste pedido pelo professor: [ ]
- O que mudei e em que seção: [ ]

## 9. Revisão por Pares 1

Cada par responde sim, em parte ou não, com o trecho deste arquivo que sustenta a resposta.

| Critério | Par 1 | Par 2 | O que eu mudo |
|----------|-------|-------|---------------|
| O processo está bem recortado? | | | |
| A abordagem é a adequada? | | | |
| Os dados existem de fato? | | | |
| A fronteira humana está no lugar certo? | | | |

## 10. Camada de governança (dia 2, bloco de governança)

Seção preenchida na manhã de 08/12. Ela responde a quatro perguntas: quem opera
o agente, quem revisa a saída, o que o agente nunca decide sozinho e qual sinal
indica que ele precisa ser desligado.

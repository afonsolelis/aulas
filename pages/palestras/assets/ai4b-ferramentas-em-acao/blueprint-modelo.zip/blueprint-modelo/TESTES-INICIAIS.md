# Comportamento esperado e primeiros testes · [nome da solução]

Participante: [nome]   Aplicativo: [Claude Code | Codex]   Data: 07/12/2026

> Este arquivo fica na raiz da pasta do projeto, ao lado de BLUEPRINT.md.
> As seções 1 e 2 são escritas antes de construir, inclusive enquanto você
> espera o gate. A saída esperada de cada teste é escrita antes de rodar, a
> partir da regra do negócio, para que a resposta do agente não molde o
> critério de correção. As entradas de teste ficam em casos/ e são fictícias
> ou anonimizadas.

## 1. Comportamento esperado

| Situação | O que o agente faz | O que entrega | Quando para e devolve a uma pessoa |
|----------|--------------------|---------------|------------------------------------|
| Caso típico | | | |
| Dado ausente ou ilegível | | | |
| Pedido de decisão reservada a uma pessoa | | | |
| Pedido fora do processo | | | |

## 2. Casos de borda

Liste ao menos três: um valor exatamente no limite de uma regra, uma entrada
incompleta ou fora do formato e uma situação que a regra do negócio não prevê.

| # | Caso de borda | Por que é borda | Comportamento esperado |
|---|---------------|-----------------|------------------------|
| B1 | | | |
| B2 | | | |
| B3 | | | |

## 3. Primeiros testes

Cada teste roda em uma conversa nova. Resultado: confere, confere em parte ou
não confere. Cada ajuste muda um único arquivo (instruções, skill ou
permissões), para que se saiba qual mudança produziu a diferença.

| # | Entrada (arquivo em casos/) | Saída esperada, escrita antes | 1ª execução | Ajuste e arquivo alterado | Depois do ajuste |
|---|-----------------------------|-------------------------------|-------------|---------------------------|------------------|
| T1 | | | | | |
| T2 | | | | | |
| T3 | | | | | |
| T4 | | | | | |

## 4. Revisão por Pares 2

- O que a solução faz bem: [ ]
- Onde ela falhou no teste: [ ]
- O caso que o colega tentaria para quebrá-la: [ ]
  Este caso entra como teste pendente e é executado no dia 2.

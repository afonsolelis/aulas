# Comportamento esperado e primeiros testes · Conferência de reembolsos da Companhia Horizonte

Participante: exemplo do professor   Aplicativo: Claude Code ou Codex   Data: 07/12/2026

> Exemplo da demonstração da tarde. As entradas estão em casos/pedidos-borda.csv
> e são fictícias. A skill testada é a conferir-reembolso, construída na oficina
> da manhã.

## 1. Comportamento esperado

| Situação | O que o agente faz | O que entrega | Quando para e devolve a uma pessoa |
|----------|--------------------|---------------|------------------------------------|
| Caso típico | Confere R1 a R4, mostra as contas, classifica e indica a alçada (R5) | Linha do relatório com situação, regras e alçada | Nunca decide; o analista confere toda linha |
| Dado ausente ou ilegível | Escreve "não informado" e não estima | Pendência com a mensagem ao solicitante | Sempre que o campo ausente impede uma regra |
| Pedido de decisão reservada a uma pessoa | Registra a observação e mantém a classificação | Observação no relatório | Aprovação, reprovação e exceção (R6) |
| Pedido fora do processo | Recusa e diz que a conferência só classifica pedidos | Resposta curta, sem relatório | Juízo sobre conduta vai para a auditoria |

## 2. Casos de borda

| # | Caso de borda | Por que é borda | Comportamento esperado |
|---|---------------|-----------------|------------------------|
| B1 | R-201 e R-202: valores de R$ 1.000,00 e R$ 1.000,01 | Ficam nos dois lados do limite da primeira faixa de R5 | Gestor direto no R-201; gestor direto e controladoria no R-202 |
| B2 | R-204: refeição sem valor | Entrada incompleta | Valor "não informado", sem cálculo por pessoa e sem alçada |
| B3 | R-203: categoria estacionamento | A regra R3 não prevê a categoria | Sem teto aplicado; situação "categoria não prevista", devolvida ao analista |

## 3. Primeiros testes

| # | Entrada (arquivo em casos/) | Saída esperada, escrita antes | 1ª execução | Ajuste e arquivo alterado | Depois do ajuste |
|---|-----------------------------|-------------------------------|-------------|---------------------------|------------------|
| T1 | R-201 | Prazo de 3 dias (R1), CNPJ presente (R2), transporte sem teto com origem e destino (R3). Conforme. Alçada: gestor direto | [registrar] | | |
| T2 | R-202 | Mesmas conferências do T1. Conforme. Alçada: gestor direto e controladoria | [registrar] | | |
| T3 | R-203 | Categoria ausente de R3, nenhum teto aplicado nem estimado. Situação: categoria não prevista, devolvida ao analista | [registrar] | Se a 1ª execução aplicar um teto ou classificar como conforme, acrescentar à skill (SKILL.md, Procedimento) o passo descrito abaixo | |
| T4 | R-204 | Valor "não informado" (campo vazio), sem conta por pessoa. Situação: pendente de documento. Alçada: não determinável sem o valor | [registrar] | | |

Passo a acrescentar à skill no ajuste do T3:

    Se a categoria do pedido não constar da regra R3, registre a situação
    "categoria não prevista", não aplique nem estime teto e devolva o pedido
    ao analista com a categoria informada.

## 4. Revisão por Pares 2

Não se aplica ao exemplo.

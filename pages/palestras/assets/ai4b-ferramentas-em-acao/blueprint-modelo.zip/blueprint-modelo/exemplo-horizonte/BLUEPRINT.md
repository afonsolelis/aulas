# Blueprint de Solução · Conferência de reembolsos da Companhia Horizonte

Participante: exemplo do professor   Setor: financeiro (empresa fictícia)   Dupla: não se aplica
Aplicativo: Claude Code ou Codex   Data: 07/12/2026
Situação: exemplo preenchido para a demonstração da tarde

> Todos os nomes, valores e CNPJs deste exemplo são fictícios. A pasta de
> referência é oficina-reembolsos, usada na oficina da manhã.

## 1. Processo recortado

- O processo em uma frase: a área financeira confere cada pedido de reembolso de despesas contra a política e o encaminha ao aprovador da alçada.
- Quem executa hoje e com que frequência: um analista financeiro, diariamente, à medida que os pedidos chegam.
- Começa quando: o pedido chega pelo formulário, com valor, categoria, quantidade, CNPJ e descrição.
- Termina quando: o analista registra a situação do pedido e o encaminha ao aprovador indicado pela regra R5.
- Volume e tempo hoje: cerca de 400 pedidos por mês (número ilustrativo do exemplo).
- O que fica fora deste recorte: o pagamento, a decisão de exceção (R6) e a investigação de padrões atípicos.

## 2. Decomposição em etapas

| # | Etapa | Recorrente ou decisória | Abordagem | Contexto de que precisa | Ferramentas de que precisa | Nível de automação |
|---|-------|-------------------------|-----------|-------------------------|----------------------------|--------------------|
| 1 | Encaminhar o pedido pela faixa de valor | Recorrente | Automação sem IA | Regra R5 | Sistema de pedidos | Completa |
| 2 | Conferir o pedido contra as regras R1 a R4 | Recorrente e decisória | Assistente com skill | Política de reembolso | Pasta com a política e o CSV de pedidos | Com supervisão |
| 3 | Consolidar a semana para os gestores | Recorrente | Job com a mesma skill | Política e pedidos da semana | Execução agendada | Com supervisão |
| 4 | Decidir a exceção à política | Decisória | Humano | Justificativa do solicitante | Nenhuma | Nenhuma |
| 5 | Investigar padrões atípicos | Decisória | Agente, adiado | Cartão, agenda e notas fiscais | Conexões tratadas no dia 2 | Nenhuma |

Etapa que o agente executa nesta versão: 2, porque concentra a leitura repetitiva de texto variável e a classificação continua sendo conferida pelo analista.

## 3. Dados e insumos

| Dado ou documento | Fonte | Formato | Acesso hoje | Dado pessoal ou sigiloso | Como entra no projeto |
|-------------------|-------|---------|-------------|--------------------------|-----------------------|
| Política de reembolso | Intranet da área financeira | Markdown (docs/politica-de-reembolso.md) | Confirmado | Não | Texto integral, fictício |
| Pedidos da semana | Exportação do sistema de pedidos | CSV (dados/pedidos-semana.csv) | Confirmado | Sim: nome do solicitante e centro de custo | Fictício |
| Casos de borda | Escritos pelo analista | CSV (casos/pedidos-borda.csv) | Não se aplica | Não | Fictício |

Fonte real que a integração do dia 2 deve conectar: o sistema de pedidos, por exportação agendada ou por conexão direta, com acesso liberado pela área de tecnologia.

## 4. Lógica do fluxo

1. Gatilho: o analista chama a skill conferir-reembolso indicando o arquivo de pedidos.
2. Passos da etapa executada pelo agente:
   - ler a política inteira antes do arquivo de pedidos;
   - conferir R1 a R4 em cada pedido, citando a regra e o campo usados;
   - mostrar cada conta (por pessoa, por diária, por quilômetro) para o analista conferir;
   - classificar o pedido e indicar a alçada pela regra R5.
3. Saída: relatório em saida/conferencia-AAAA-MM-DD.md, lido pelo analista antes de qualquer encaminhamento.
4. O agente para e devolve a uma pessoa quando: a categoria não está prevista na política, falta valor, a descrição pede aprovação ou o pedido depende de exceção (R6).

## 5. Fronteira humana

| Decisão | Quem decide | Por que fica com uma pessoa | O que impede o agente |
|---------|-------------|-----------------------------|-----------------------|
| Aprovar ou reprovar o pedido | Aprovador da alçada (R5) | Alçada de valor definida pela política | Regra no CLAUDE.md ou AGENTS.md e limite da skill; o agente não tem acesso ao sistema de pedidos |
| Aceitar exceção à política | Controladoria (R6) | A controladoria responde pela exceção | Limite da skill, que só lista as regras afetadas |
| Alterar dados de um pedido | Solicitante, pelo formulário | O pedido é um registro de outra pessoa | Claude Code: deny em Edit(./dados/**); Codex: revisão das alterações e reversão pelo Git |
| Julgar a conduta do solicitante | Auditoria interna | Julgamento sobre pessoas | Regra nas instruções e na skill |

## 6. Abordagem e ferramenta candidatas

- Abordagem da etapa executada: assistente com a skill conferir-reembolso.
- Quem dispara a execução: o analista, a cada lote de pedidos.
- O caminho é fixo ou varia de caso para caso: o procedimento é fixo, mas a descrição e o comprovante variam e exigem leitura de texto.
- Quem lê a saída antes de ela produzir efeito: o analista, que confere a classificação e as contas.
- Quanto custa um erro que ninguém revisou: um reembolso pago fora da política ou um pedido correto devolvido ao solicitante.
- Abordagem mais simples considerada e por que ela não basta: uma automação sem IA resolve a faixa de valor (etapa 1), mas não lê a descrição livre nem identifica item não reembolsável.
- Ferramenta: Claude Code ou Codex; peças previstas: arquivo de instruções, skill conferir-reembolso e regras de permissão sobre dados/ e docs/.

## 7. Limites e conformidade (primeira leitura)

- O que o agente nunca faz: aprovar, reprovar, alterar pedidos, estimar campo ausente ou emitir juízo sobre a conduta do solicitante.
- Dados pessoais envolvidos e para que são usados: nome do solicitante e centro de custo, usados apenas para identificar o pedido no relatório.
- Regra da empresa sobre uso de ferramenta externa e classificação da informação: a confirmar com a área de tecnologia antes de usar pedidos reais.
- Perguntas para o bloco de governança do dia 2: quem revisa uma amostra dos relatórios e com que frequência; o que acontece se a política mudar e a skill não for atualizada.

## 8. Registro do gate

- Horário da conversa: não se aplica (exemplo).
- Resultado: não se aplica.

## 9. Revisão por Pares 1

Não se aplica ao exemplo.

## 10. Camada de governança (dia 2, bloco de governança)

Seção preenchida na manhã de 08/12.

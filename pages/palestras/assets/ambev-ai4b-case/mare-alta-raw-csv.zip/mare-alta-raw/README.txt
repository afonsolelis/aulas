Maré Alta Beverages - case dataset (raw release)
Synthetic data created for teaching. No real company, outlet or brand is represented.
Fiscal year runs from October to September (FY24 = Oct 2023 to Sep 2024).
Volumes in hectolitres (1 HL = 100 litres); monetary values in Brazilian reais (BRL).
CSV files: UTF-8, comma separator, point as decimal mark. See the data dictionary.


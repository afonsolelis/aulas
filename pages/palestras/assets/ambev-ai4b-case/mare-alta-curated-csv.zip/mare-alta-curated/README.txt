Maré Alta Beverages - case dataset (curated release)
Synthetic data created for teaching. No real company, outlet or brand is represented.
Fiscal year runs from October to September (FY24 = Oct 2023 to Sep 2024).
Volumes in hectolitres (1 HL = 100 litres); monetary values in Brazilian reais (BRL).
CSV files: UTF-8, comma separator, point as decimal mark. See the data dictionary.

RELEASE NOTE - curated release, prepared by the data team after the review of the raw extract
Corrected:
1. Region labels in pos.region standardised to Southeast, South, Northeast and Central-West.
2. Sales of the South region for March 2026 had been loaded twice; the duplicate rows were removed.
3. Volumes sent by the LEGACY_NE system for January to March 2025 were in litres; converted to hectolitres.
4. One order of February 2026 (POS-10993, product P02) keyed with two extra digits was corrected.
5. Spend types sent by LEGACY_NE were mapped to the standard labels.
Not changed, pending a decision of the business:
6. income_index and channel are missing for part of the points of sale, mostly in LEGACY_NE. The values do not exist in the source.
7. Negative rows in sales_monthly are returns and credit notes. They were kept.
8. trade_spend has rows for points of sale that are no longer in the master table. They were kept.
